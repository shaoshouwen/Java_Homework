package club.banyuan.controller;

import club.banyuan.entity.Auction_item;
import club.banyuan.service.ModifyItemService;
import club.banyuan.service.impl.ModifyItemServiceImpl;

import java.sql.SQLException;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "AddItemServlet", urlPatterns = "/add.do")
public class AddItemServlet extends HttpServlet {

  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    ModifyItemService modifyItemService = new ModifyItemServiceImpl();
    Auction_item auction_item = new Auction_item();
    String item_name = request.getParameter("item_name");
    String description = request.getParameter("description");
    Double starting_price = Double.valueOf(request.getParameter("starting_price"));
    Double base_price = Double.valueOf(request.getParameter("base_price"));
    String start_time = request.getParameter("start_time");
    String end_time = request.getParameter("end_time");
//    Double base_price = Double.valueOf(request.getParameter("base_price"));
    auction_item.setItem_name(item_name);
    auction_item.setDescription(description);
    auction_item.setStart_time(start_time);
    auction_item.setEnd_time(end_time);
    auction_item.setBase_price(base_price);
    auction_item.setStarting_price(starting_price);
    int id = 0;
    try {
      id = modifyItemService.insertitem(auction_item);
      if (id > 0) {
        request.getRequestDispatcher("show.do").forward(request, response);
      }


    } catch (SQLException throwables) {
      throwables.printStackTrace();
    }


  }

  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    doPost(request, response);
  }
}
